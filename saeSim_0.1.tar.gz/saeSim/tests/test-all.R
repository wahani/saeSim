library(testthat)
library(saeSim)

test_check("saeSim")
