setGeneric("plot")

setMethod("plot", c(x = "sim_setup", y = "character"),
          function(x, y, xlab = y, ylab = "y", ...) {
            dat <- sim(x@base, S3Part(x, TRUE), x@idC)
            smoothScatter(y=dat$y, x = dat[[y]], xlab = xlab, ylab = ylab, ...)
          })

setMethod("plot", c(x = "sim_setup", y = "missing"),
          function(x, y, ...) {
            dat <- sim(x@base, S3Part(x, TRUE), x@idC)
            y <- names(dat)[!grepl("id|y", names(dat))][1]
            smoothScatter(y=dat$y, x = dat[[y]], xlab = y, ylab = "y", ...)
          })